﻿using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace AspNetExtendingIdentityRoles.Models
{
    //public class ApplicationUserRole : IdentityUserRole
    //{
    //    new public virtual ApplicationRole Role { get; set; }
    //    new public virtual ApplicationUser User { get; set; }
    //}


}